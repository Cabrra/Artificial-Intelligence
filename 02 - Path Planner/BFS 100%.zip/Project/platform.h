#pragma once

// Used to export DLL functions
#define DLLEXPORT __declspec(dllexport)
